HTML, CSS, javascript and Bootstap 5 

#TOOLS EQUIPED
! ionicon == (https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
                    "https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js")
! Bootsrap == (https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css)