//toggle sidebar
let menuicn = document.querySelector(".menuicn");
let nav = document.querySelector(".navcontainer");
 
menuicn.addEventListener("click", () => {
    nav.classList.toggle("navclose");
})

//
let list = document.querySelectorAll(".navigation li");
function activeLink(){
    list.forEach((items) =>
        items.classList.remove('hovered'));
        this.classList.add('hovered');
}
list.forEach((item)=>
item.addEventListener('mouseover',activeLink));